class BoulderDash
{
    constructor(canvasId)
    {
        this.tiles = [];
        this.tileSize = 32;
        this.tileRows = 22;
        this.tittlesInRow = 40;

        this.initializeCanvas(canvasId);
        this.generateLevel();
        this.loadSprite();
        this.initializeMiner();
        this.subcribeToKeyboardEvents();
        
    }
    loadSprite()
    {
        this.tilesSprite = new Image();
        this.tilesSprite.src = "./sprites.png";
        this.tilesSprite.onload = () => {
            this.renderLevel();
        };
    }
    initializeCanvas(canvasId)
    {
        if (!canvasId) 
            throw new Error("Wpisz canvas id!");
        this.canvas = document.querySelector("#"+canvasId);
        this.ctx = this.canvas.getContext("2d");
    }
    subcribeToKeyboardEvents()
    {
        document.addEventListener('keydown', (e) => this.onKeyDown(e));
    }
    onKeyDown(e)
    {
        let xBias, yBias;
        switch (e.code) {
            case "ArrowDown":
                xBias = 0;
                yBias = 1;
                break;
            case "ArrowUp":
                xBias = 0;
                yBias = -1;
                break;
            case "ArrowLeft":
                xBias = -1;
                yBias = 0;
                break;
            case "ArrowRight":
                xBias = 1;
                yBias = 0;
                break;
        }
        this.updateMierPos(xBias, yBias);
        this.renderLevel();
    }
    updateMierPos(xBias, yBias)
    {
        const newXPos = this.miner.xPos + xBias;
        const newYPos = this.miner.xPos + xBias;
        if (newXPos >=0 && newYPos >=0 && newXPos < this.tittlesInRow-1 && newYPos < this.tileRows-1)
        {
            this.miner.move(xBias, yBias);
            this.tiles[this.miner.yPos][this.miner.xPos] = this.miner;    
        }
        
    }
    initializeMiner()
    {
        this.miner = new Miner();
        this.tiles[this.miner.yPos][this.miner.xPos] = this.miner;

    }
    renderLevel()
    {
        for (let y = 0; y < this.tileRows; y++)
            for (let x = 0; x < this.tittlesInRow; x++)
                {
                    const tile = this.tiles[y][x];
                    const xPos = x * this.tileSize;
                    const yPos = y * this.tileSize;
                    this.ctx.drawImage(
                        this.tilesSprite, 
                        tile.spriteXPos,
                        tile.spriteYPos,
                        this.tileSize,
                        this.tileSize,
                        xPos,
                        yPos,
                        this.tileSize,
                        this.tileSize
                    )
                }
    }
    generateLevel()
    {
        for (let y = 0; y < this.tileRows; y++)
        {
            const row = [];
            for (let x = 0; x < this.tittlesInRow; x++)
            {
                const rand = Math.floor(Math.random() * 100);
                let randTileType
                if (rand < 15)
                    randTileType = TileProperties.empty.type;
                else if (rand < 55)
                    randTileType = TileProperties.sand.type;
                else if (rand < 80)
                    randTileType = TileProperties.stone.type;
                else if (rand < 95)
                    randTileType = TileProperties.wall.type;
                else 
                    randTileType = TileProperties.diamond.type;

                const tile = new Tile(randTileType);
                row.push(tile);
            }
            this.tiles.push(row);
        }
    }
}