class Miner extends Tile {
    constructor() {
        super(TileProperties.miner.type);
        this.xPos = 1;
        this.yPos = 1;
    }    
    move(xBias, yBias) {
        this.xPos += xBias;
        this.yPos += yBias;
    }
}